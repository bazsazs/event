const form = document.getElementById("myForm");
        const input = document.getElementById("myInput");
        const button = document.getElementById("myButton");

        // Event listener
        button.addEventListener("click", function () {
            // Eseménykezelő funkció
            console.log("Űrlap küldése:", input.value);
        });